# IMPERIUM – Online-Backend (erste Integrationsstufe)

## Status
Diese Dateien bilden den sicheren Firebase-Unterbau als **Deployment-Vorbereitung**.
Noch nicht live: Es wurde kein Firebase-Projekt erstellt, keine Domain verbunden und kein Deployment ausgeführt.
Die vorhandene lokale Spieloberfläche bleibt unverändert und ist noch nicht mit diesen Funktionen verdrahtet.

## Architektur
- Firebase Authentication: Registrierung, Anmeldung, E-Mail-Verifizierung und Passwort-Reset (im nächsten Integrationsschritt an die UI anbinden).
- Cloud Functions (Node.js 22, Region europe-west1): vertrauenswürdige Spielaktionen.
- Cloud Firestore: Spielerkonten und private Städte.
- Firestore Rules: Client darf keine Spielstände direkt verändern.
- Firebase Hosting: HTTPS-Auslieferung der bestehenden Weboberfläche.

## Einrichtung nach Verbindung des Firebase-Kontos
1. Firebase-Projekt anlegen und Web-App aktivieren.
2. Authentication: E-Mail/Passwort aktivieren und E-Mail-Verifizierung erzwingen.
3. Firestore in europe-west1 anlegen.
4. Firebase CLI installieren/anmelden: `npm install -g firebase-tools`, `firebase login`.
5. Im Ordner `engine`: `firebase use --add` und Projekt-ID auswählen.
6. `cd functions && npm install && npm run build`.
7. Zurück in `engine`: `firebase deploy --only firestore:rules,functions,hosting`.

## Sicherheitsregeln
- Niemals Admin-Schlüssel oder Service-Account-Dateien in den Browser legen.
- Client darf keine Ressourcen, Geldbeträge, Einheiten, Forschungszeiten oder Kampfresultate direkt schreiben.
- Jede Spielaktion braucht Authentifizierung, Besitzprüfung, serverseitige Kosten-/Voraussetzungsprüfung, Idempotenz und Audit-Protokoll.
- Produktions- und Forschungsfortschritt wird anhand von Serverzeit berechnet.
- Vor öffentlichem Start: Abuse-Schutz/App Check, Rate Limits, Backups, Monitoring, Datenschutz/Impressum und Lasttests ergänzen.

## Noch offen
Die vorhandene `index.html` nutzt derzeit lokale Spielstände. Die Migration auf Auth, serverseitige Befehle und Cloud-Spielstände ist ein eigener Integrationsschritt; bis dahin ist das Projekt nicht als echtes Multiplayer-Spiel zu bezeichnen.
