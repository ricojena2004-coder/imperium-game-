# IMPERIUM V7 – Web client and online migration

The root `index.html` remains the current playable local prototype.
The `engine/` directory contains the incremental Phaser/TypeScript migration scaffold.
Firebase deployment preparation is in `FIREBASE-ONLINE-SETUP.md`, with rules and Cloud Functions.
No Firebase project has been provisioned and no public deployment has been performed yet.
