import { initializeApp } from "firebase-admin/app";
import { getFirestore, FieldValue } from "firebase-admin/firestore";
import { onCall, HttpsError } from "firebase-functions/v2/https";
import { setGlobalOptions } from "firebase-functions/v2";

initializeApp();
const db = getFirestore();
setGlobalOptions({ region: "europe-west1", maxInstances: 10 });

const eras = [
  "Steinzeit", "Bronzezeit", "Antike", "Mittelalter", "Renaissance",
  "Industriezeitalter", "Frühe Moderne",
  "Nachkriegs- und Informationszeitalter", "Gegenwart", "Zukunft"
] as const;

function requireUid(request: { auth?: { uid: string } | null }): string {
  if (!request.auth?.uid) throw new HttpsError("unauthenticated", "Bitte zuerst anmelden.");
  return request.auth.uid;
}

export const bootstrapPlayer = onCall(async (request) => {
  const uid = requireUid(request);
  const displayName = typeof request.data?.displayName === "string"
    ? request.data.displayName.trim().slice(0, 24) : "";
  if (displayName.length < 3) {
    throw new HttpsError("invalid-argument", "Der Spielername muss 3 bis 24 Zeichen lang sein.");
  }

  const playerRef = db.doc(`players/${uid}`);
  const cityRef = db.doc(`cities/${uid}`);
  await db.runTransaction(async (tx) => {
    const existing = await tx.get(playerRef);
    if (existing.exists) return;
    const city = await tx.get(cityRef);
    if (city.exists) throw new HttpsError("already-exists", "Stadt existiert bereits.");
    tx.create(playerRef, {
      uid, displayName, nation: null, era: 0, createdAt: FieldValue.serverTimestamp(),
      status: "online", profileVersion: 1
    });
    tx.create(cityRef, {
      ownerUid: uid, era: 0, eraName: eras[0], coreLevel: 1,
      resources: { geld: 500, anleihen: 0, holz: 100, stein: 100 },
      buildings: [], cityVersion: 1, createdAt: FieldValue.serverTimestamp(),
      updatedAt: FieldValue.serverTimestamp()
    });
  });
  return { ok: true, playerId: uid };
});

export const getMyGame = onCall(async (request) => {
  const uid = requireUid(request);
  const [player, city] = await Promise.all([
    db.doc(`players/${uid}`).get(), db.doc(`cities/${uid}`).get()
  ]);
  if (!player.exists || !city.exists) {
    throw new HttpsError("failed-precondition", "Spielkonto noch nicht eingerichtet.");
  }
  return { player: player.data(), city: city.data() };
});

// Initial command gateway. Only validated, server-owned actions will be added here.
// The client is deliberately not allowed to submit arbitrary city/resource snapshots.
export const submitGameCommand = onCall(async (request) => {
  requireUid(request);
  const command = request.data?.command;
  if (typeof command !== "string" || command.length > 48) {
    throw new HttpsError("invalid-argument", "Ungültiger Spielbefehl.");
  }
  throw new HttpsError(
    "failed-precondition",
    `Spielbefehl '${command}' ist noch nicht freigeschaltet. Die serverseitige Regelprüfung wird schrittweise ergänzt.`
  );
});
