# Backend contract scaffold (not a running service)
Production API should be server-authoritative:
- POST /auth/register, /auth/login, /auth/refresh
- GET/PUT /v1/cities/:id (versioned save envelope)
- POST /v1/production/orders and POST /v1/research/orders
- GET /v1/world/regions and POST /v1/trades
Every mutation requires authenticated player ownership, idempotency key, version check and audit event.
Offline progress must be computed from server timestamps and bounded server rules, never trusted from client clocks.
