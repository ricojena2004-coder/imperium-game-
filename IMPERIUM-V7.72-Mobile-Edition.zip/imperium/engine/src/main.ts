// IMPERIUM V7.5 engine migration scaffold. The live prototype remains index.html.
import Phaser from 'phaser';
import { GameScene } from './scenes/GameScene';
const config: Phaser.Types.Core.GameConfig = {
  type: Phaser.AUTO, width: 1280, height: 720, backgroundColor: '#172820',
  parent: 'game-root', scene: [GameScene],
  scale: { mode: Phaser.Scale.FIT, autoCenter: Phaser.Scale.CENTER_BOTH }
};
new Phaser.Game(config);
