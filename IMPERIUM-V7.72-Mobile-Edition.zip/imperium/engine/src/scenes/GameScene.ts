import Phaser from 'phaser';
export class GameScene extends Phaser.Scene {
  constructor(){ super('GameScene'); }
  create(){
    this.add.text(32,32,'IMPERIUM V7.5 · Engine scaffold',{fontFamily:'Georgia',fontSize:'28px',color:'#e8d3a0'});
    this.add.text(32,78,'Phaser 4 scene bootstrapping point – gameplay migration is incremental.',{fontSize:'16px',color:'#d8e0d5'});
  }
}
