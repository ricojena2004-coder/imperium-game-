import { describe, expect, it } from 'vitest';
describe('hex combat rules',()=>{
  const distance=(a:{x:number,y:number},b:{x:number,y:number})=>(Math.abs(a.x-b.x)+Math.abs(a.y-b.y)+Math.abs(a.x+a.y-b.x-b.y))/2;
  it('counts adjacent axial hexes as distance one',()=>expect(distance({x:2,y:2},{x:3,y:2})).toBe(1));
  it('counts two-step hex distance',()=>expect(distance({x:2,y:2},{x:4,y:2})).toBe(2));
});
